This file describes how to run this project and also what the output shows:
(User need to make sure he is using latest java on the machine)

This project is developed on java version "1.8.0_181"
SANKALPs-MacBook-Air:~ sankalpmotke$  java -version
java version "1.8.0_181"


Running Project : There are two ways of running this project
1. Using eclipse
2. Using command prompt


1. Using eclipse
----------------
Here we are considering end user is fully aware of how to use eclipse.

1. Open your existing workspace in Eclipse.
2. In the Eclipse menu, choose File -> Import.
3. Expand the General folder and select Existing Projects into Workspace, then click Next.
4. You should now see the Import Projects dialog. Browse to the location containing the project
5. Select Finish.
6. Now click the run button (it will compile and run the project)


Information how to run the project :-
-----------------------------------------------------------------------------------------


1. Runner.java is the main class to start the project.


2. Run the program the user will be asked which type of strategy to run as mentioned below.
----------------------------------------------------------------------------
	"Press 1,2,3 or 4 to select choices:

		1. Strategy-1 (Rank Selection, One point crossover and uniform mutation)
		2. Strategy-2 (Tournament Selection, Two point crossover and flip mutation)
		3. Strategy-3 (Rank Selection, Two point crossover and uniform mutation)
		4. Exit

	Enter your choice!"
----------------------------------------------------------------------------


3. Once the user provides the type of strategy. User will be asked to enter the target string that he wants to find using the Genetic Algorithm Strategy as shown below.
----------------------------------------------------------------------------		
	"
		Enter your choice!
		1
		Enter 5 digits target string to be found
 			(Ony 0 and 1 allowed)
	"
----------------------------------------------------------------------------

Note : Only five digits are allowed as the target string. 
       Only 0 and 1 are allowed as per the instruction. 
(It is considered that user know how to enter the target string on the console)

4. Here we are giving target string as 11111  and the genetic algorithm will Strat processing as mentioned below from step 1 to step 4 all shown below.

----------------------------------------------------------------------------
Press 1,2,3 or 4 to select choices:

1. Strategy-1 (Rank Selection, One point crossover and uniform mutation)
2. Strategy-2 (Tournament Selection, Two point crossover and flip mutation)
3. Strategy-3 (Rank Selection, Two point crossover and uniform mutation)
4. Exit

Enter your choice!
1
Enter 5 digits target string to be found
 (Ony 0 and 1 allowed)
1
1
1
1
1

*** Generating Population ***

Chromosome 0 [1, 0, 1, 1, 0] with Fitness = 3
Chromosome 1 [0, 1, 0, 1, 0] with Fitness = 2
Chromosome 2 [1, 1, 0, 1, 1] with Fitness = 4
Chromosome 3 [0, 0, 1, 0, 1] with Fitness = 2
Chromosome 4 [1, 0, 0, 1, 0] with Fitness = 2
Chromosome 5 [1, 1, 1, 1, 0] with Fitness = 4
Chromosome 6 [0, 1, 0, 0, 0] with Fitness = 1
Chromosome 7 [1, 1, 0, 1, 1] with Fitness = 4
Chromosome 8 [1, 1, 1, 0, 0] with Fitness = 3
Chromosome 9 [1, 0, 1, 1, 1] with Fitness = 4


In Generation : 0 Fittest found : 4
After Selection
Fittest chromosome:[1, 0, 1, 1, 1]
Second Fittest chromosome:[1, 1, 1, 1, 0]

One Point Crossover :
Crossover Point  = 3
After Crossover :
[1, 1, 1, 1, 1]
[1, 0, 1, 1, 0]

After Mutation
[0, 0, 0, 0, 0]
[0, 0, 0, 0, 1]
In Generation : 1 Fittest found : 4
After Selection
Fittest chromosome:[1, 1, 0, 1, 1]
Second Fittest chromosome:[1, 1, 0, 1, 1]

One Point Crossover :
Crossover Point  = 1
After Crossover :
[1, 1, 0, 1, 1]
[1, 1, 0, 1, 1]

After Mutation
[1, 1, 1, 1, 1]
[1, 1, 1, 1, 1]
In Generation : 2 Fittest found : 5
----------------------------------------------------------------------------

5. So we have found our target string in second generation





2. Run using command prompt
------------------------

First you should be in the src folder of this project and then you need to compile each class inside their respective package folder.
To run you need to use the package syntax as below:  
com.runner\Runner.java is the main class to start the project. After all the classes are compiled then run command - java Runner 


Compile statements:

src>javac -d ..\bin .\com.crossover\*.java
src>javac -d ..\bin .\com.factories\*.java
src>javac -d ..\bin .\com.generation\*.java
src>javac -d ..\bin .\com.geneticalgorithm\*.java
src>javac -d ..\bin .\com.mutation\*.java
src>javac -d ..\bin .\com.runner\*.java
src>javac -d ..\bin .\com.selection\*.java
src>javac -d ..\bin .\com.strategy\*.java

Run Statement:

src>java -cp ..\bin  com.runner.Runner


----------------------------------------------------------------------------
Press 1,2,3 or 4 to select choices:

1. Strategy-1 (Rank Selection, One point crossover and uniform mutation)
2. Strategy-2 (Tournament Selection, Two point crossover and flip mutation)
3. Strategy-3 (Rank Selection, Two point crossover and uniform mutation)
4. Exit

Enter your choice!
1
Enter 5 digits target string to be found
 (Ony 0 and 1 allowed)
1
1
1
1
1

*** Generating Population ***

Chromosome 0 [1, 0, 1, 1, 0] with Fitness = 3
Chromosome 1 [0, 1, 0, 1, 0] with Fitness = 2
Chromosome 2 [1, 1, 0, 1, 1] with Fitness = 4
Chromosome 3 [0, 0, 1, 0, 1] with Fitness = 2
Chromosome 4 [1, 0, 0, 1, 0] with Fitness = 2
Chromosome 5 [1, 1, 1, 1, 0] with Fitness = 4
Chromosome 6 [0, 1, 0, 0, 0] with Fitness = 1
Chromosome 7 [1, 1, 0, 1, 1] with Fitness = 4
Chromosome 8 [1, 1, 1, 0, 0] with Fitness = 3
Chromosome 9 [1, 0, 1, 1, 1] with Fitness = 4


In Generation : 0 Fittest found : 4
After Selection
Fittest chromosome:[1, 0, 1, 1, 1]
Second Fittest chromosome:[1, 1, 1, 1, 0]

One Point Crossover :
Crossover Point  = 3
After Crossover :
[1, 1, 1, 1, 1]
[1, 0, 1, 1, 0]

After Mutation
[0, 0, 0, 0, 0]
[0, 0, 0, 0, 1]
In Generation : 1 Fittest found : 4
After Selection
Fittest chromosome:[1, 1, 0, 1, 1]
Second Fittest chromosome:[1, 1, 0, 1, 1]

One Point Crossover :
Crossover Point  = 1
After Crossover :
[1, 1, 0, 1, 1]
[1, 1, 0, 1, 1]

After Mutation
[1, 1, 1, 1, 1]
[1, 1, 1, 1, 1]
In Generation : 2 Fittest found : 5
----------------------------------------------------------------------------