package com.mutation;

import com.generation.FitnessOperations;
import com.generation.GeneGenerator;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class MutationOne implements uniform type of mutation.
 */
public class MutationOne implements Mutation {

	/**
	 * Instantiates a new mutation one.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperation    is the instance of FitnessOperations
	 */
	public MutationOne(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {
		mutation(populationGenerator, fitnessOperation);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mutation.Mutation#mutation(com.generation.PopulationGenerator,
	 * com.generation.FitnessOperations) it performs uniform mutation on selected
	 * chromosome
	 */
	public void mutation(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {

		GeneGenerator fittestChromosome;
		GeneGenerator secondFittestChromosome;

		fittestChromosome = fitnessOperation.getFittest(populationGenerator);
		secondFittestChromosome = fitnessOperation.getSecondFittest(populationGenerator);

		/**
		 * perform uniform mutation on the fittestChromosome
		 */
		for (int x = 0; x < fittestChromosome.geneLength; x++) {
			if (Math.random() < 0.50) {
				fittestChromosome.genes[x] = 1;
			} else {
				fittestChromosome.genes[x] = 0;
			}
		}

		/**
		 * perform uniform mutation on the secondFittestChromosome
		 */
		for (int x = 0; x < secondFittestChromosome.geneLength; x++) {
			if (Math.random() < 0.50) {
				secondFittestChromosome.genes[x] = 1;
			} else {
				secondFittestChromosome.genes[x] = 0;
			}
		}

		System.out.println("After Mutation");
		System.out.println(fittestChromosome);
		System.out.println(secondFittestChromosome);
	}

}
