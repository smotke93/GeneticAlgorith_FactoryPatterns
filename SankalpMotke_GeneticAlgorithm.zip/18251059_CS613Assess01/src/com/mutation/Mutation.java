package com.mutation;

import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Interface Mutation.
 */
public interface Mutation {

	/**
	 * Mutation.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOPeration    is the instance of FitnessOperations
	 */
	public void mutation(PopulationGenerator populationGenerator, FitnessOperations fitnessOPeration);
}
