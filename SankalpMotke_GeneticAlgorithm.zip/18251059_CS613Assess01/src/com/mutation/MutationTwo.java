package com.mutation;

import java.util.Random;

import com.generation.FitnessOperations;
import com.generation.GeneGenerator;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class MutationTwo implements flip type of mutation..
 */
public class MutationTwo implements Mutation {

	/**
	 * Instantiates a new mutation two.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperation    is the instance of FitnessOperation
	 */
	public MutationTwo(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {
		mutation(populationGenerator, fitnessOperation);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mutation.Mutation#mutation(com.generation.PopulationGenerator,
	 * com.generation.FitnessOperations) it performs flip mutation on selected
	 * chromosome
	 * 
	 */
	public void mutation(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {

		GeneGenerator fittestChromosome;
		GeneGenerator secondFittestChromosome;

		Random randomNumber = new Random();

		fittestChromosome = fitnessOperation.getFittest(populationGenerator);
		secondFittestChromosome = fitnessOperation.getSecondFittest(populationGenerator);

		/**
		 * select a random mutation point
		 */
		int mutationPoint = randomNumber.nextInt(populationGenerator.chromosomeSet[0].geneLength);

		if (fittestChromosome.genes[mutationPoint] == 0) {
			fittestChromosome.genes[mutationPoint] = 1;
		} else {
			fittestChromosome.genes[mutationPoint] = 0;
		}

		/**
		 * select a random mutation point
		 */
		mutationPoint = randomNumber.nextInt(populationGenerator.chromosomeSet[0].geneLength);

		if (secondFittestChromosome.genes[mutationPoint] == 0) {
			secondFittestChromosome.genes[mutationPoint] = 1;
		} else {
			secondFittestChromosome.genes[mutationPoint] = 0;
		}
		System.out.println("After Mutation");
		System.out.println(fittestChromosome);
		System.out.println(secondFittestChromosome);

	}

}
