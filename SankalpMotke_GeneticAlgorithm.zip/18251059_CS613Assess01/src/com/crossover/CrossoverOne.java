package com.crossover;

import java.util.Random;

import com.generation.FitnessOperations;
import com.generation.GeneGenerator;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class CrossoverOne implements one point crossover type.
 */
public class CrossoverOne implements Crossover {

	/**
	 * Instantiates a new crossover one.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperations   is the instance of FitnessOperation
	 */
	public CrossoverOne(PopulationGenerator populationGenerator, FitnessOperations fitnessOperations) {
		crossover(populationGenerator, fitnessOperations);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.crossover.Crossover#crossover(com.generation.PopulationGenerator,
	 * com.generation.FitnessOperations) it performs one point crossover on randomly
	 * selected gene of chromosome
	 */
	public void crossover(PopulationGenerator populationGenerator, FitnessOperations fitnessOperations) {

		GeneGenerator fittestChromosome;
		GeneGenerator secondFittestChromosome;

		Random randomNumber = new Random();

		fittestChromosome = fitnessOperations.getFittest(populationGenerator);
		secondFittestChromosome = fitnessOperations.getSecondFittest(populationGenerator);

		int crossOverPoint = randomNumber.nextInt(populationGenerator.chromosomeSet[0].geneLength);

		System.out.println("\nOne Point Crossover :");
		System.out.println("Crossover Point  = " + crossOverPoint);

		for (int i = 0; i < crossOverPoint; i++) {
			int temp = fittestChromosome.genes[i];
			fittestChromosome.genes[i] = secondFittestChromosome.genes[i];
			secondFittestChromosome.genes[i] = temp;

		}

		System.out.println("After Crossover :");
		System.out.println(fittestChromosome);
		System.out.println(secondFittestChromosome + "\n");
	}

}
