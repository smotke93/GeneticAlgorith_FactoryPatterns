package com.crossover;

import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Interface Crossover.
 */
public interface Crossover {

	/**
	 * Crossover.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperations   is the instance of FitnessOperation
	 */
	public void crossover(PopulationGenerator populationGenerator, FitnessOperations fitnessOperations);
}
