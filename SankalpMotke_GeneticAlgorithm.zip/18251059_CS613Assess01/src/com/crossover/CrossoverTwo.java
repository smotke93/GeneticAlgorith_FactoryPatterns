package com.crossover;

import java.util.Random;

import com.generation.FitnessOperations;
import com.generation.GeneGenerator;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class CrossoverTwo implements two point crossover type.
 */
public class CrossoverTwo implements Crossover {

	/**
	 * Instantiates a new crossover two.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperations   is the instance of FitnessOperation
	 */
	public CrossoverTwo(PopulationGenerator populationGenerator, FitnessOperations fitnessOperations) {
		crossover(populationGenerator, fitnessOperations);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.crossover.Crossover#crossover(com.generation.PopulationGenerator,
	 * com.generation.FitnessOperations) it performs two point crossover on randomly
	 * selected gene of chromosome
	 */
	public void crossover(PopulationGenerator populationGenerator, FitnessOperations fitnessOperations) {

		GeneGenerator fittestChromosome;
		GeneGenerator secondFittestChromosome;

		Random randomNumber = new Random();

		fittestChromosome = fitnessOperations.getFittest(populationGenerator);
		secondFittestChromosome = fitnessOperations.getSecondFittest(populationGenerator);

		int crosspoint1 = randomNumber.nextInt(populationGenerator.chromosomeSet[0].geneLength);
		int crosspoint2 = randomNumber.nextInt(populationGenerator.chromosomeSet[0].geneLength);

		System.out.println("\nTwo Point Crossover");
		System.out.println("Crossover Point 1 = " + crosspoint1);
		System.out.println("Crossover Point 2 = " + crosspoint2);

		if (crosspoint1 == crosspoint2) {
			if (crosspoint1 == 0) {
				crosspoint2++;
			} else {
				crosspoint1--;
			}
		}

		if (crosspoint2 < crosspoint1) {
			int temp = crosspoint1;
			crosspoint1 = crosspoint2;
			crosspoint2 = temp;
		}

		System.out.println("Crossover Point 1 =  " + crosspoint1 + "\nCrossover Point 2 = " + crosspoint2);

		for (int i = crosspoint1; i < crosspoint2; i++) {

			int temp = fittestChromosome.genes[i];
			fittestChromosome.genes[i] = secondFittestChromosome.genes[i];
			secondFittestChromosome.genes[i] = temp;
		}

		System.out.println("\nAfter Crossover");
		System.out.println(fittestChromosome);
		System.out.println(secondFittestChromosome + "\n");
	}

}
