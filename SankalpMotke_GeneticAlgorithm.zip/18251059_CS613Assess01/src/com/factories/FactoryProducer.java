package com.factories;

import com.generation.FitnessOperations;
import com.geneticalgorithm.GeneticAlgorithm;

// TODO: Auto-generated Javadoc
/**
 * The Class FactoryProducer.
 */
public class FactoryProducer {

	/**
	 * Instantiates a new factory producer. Private constructor is used to hide
	 * inner one
	 */
	private FactoryProducer() {
	}

	/**
	 * getFitnessOperations
	 *
	 * @return the instance of FitnessOperations
	 */
	public static FitnessOperations getFitnessOperations() {
		return new FitnessOperations();
	}

	/**
	 * Get GeneticAlgorithm instance.
	 *
	 * @return the instance of GeneticAlgorithm
	 */
	public static GeneticAlgorithm geneticAlgorithm() {
		return new GeneticAlgorithm();
	}

}