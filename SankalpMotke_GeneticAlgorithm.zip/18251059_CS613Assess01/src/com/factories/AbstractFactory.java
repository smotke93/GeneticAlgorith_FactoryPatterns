package com.factories;

import com.crossover.Crossover;
import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;
import com.mutation.Mutation;
import com.selection.Selection;

// TODO: Auto-generated Javadoc
/**
 * A factory for creating Abstract objects.
 */
public interface AbstractFactory {

	/**
	 * getSelectionChoice is used to select one of the two types of selection.
	 *
	 * @param selectionType       : is used to select one of the two choices of
	 *                            selection (rank selection or tournament selection)
	 * @param populationGenerator : is the instance of PopulationGenerator
	 * @param fitnessOperations   : is the instance of FitnessOperations
	 * @return Selection
	 */
	public Selection getSelectionChoice(int selectionType, PopulationGenerator populationGenerator,
			FitnessOperations fitnessOperations);

	/**
	 * getCrossoverChoice is used to select one of the two types of crossover.
	 *
	 * @param crossOverType       : is used to select one of the two choices of
	 *                            crossover (one point crossover or two point
	 *                            crossover)
	 * @param populationGenerator : is the instance of PopulationGenerator
	 * @param fitnessOperations   : is the instance of FitnessOperations
	 * @return Crossover
	 */
	public Crossover getCrossoverChoice(int crossOverType, PopulationGenerator populationGenerator,
			FitnessOperations fitnessOperations);

	/**
	 * getMutateChoice is used to select one of the two types of mutation.
	 *
	 * @param mutateType          : is used to select one of the two choices of
	 *                            mutation (uniform mutation or flip mutation)
	 * @param populationGenerator : is the instance of PopulationGenerator
	 * @param fitnessOperations   : is the instance of FitnessOperations
	 * @return Mutation
	 */
	public Mutation getMutateChoice(int mutateType, PopulationGenerator populationGenerator,
			FitnessOperations fitnessOperations);

}
