package com.factories;

import com.crossover.Crossover;
import com.crossover.CrossoverOne;
import com.crossover.CrossoverTwo;
import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;
import com.mutation.Mutation;
import com.mutation.MutationOne;
import com.mutation.MutationTwo;
import com.selection.Selection;
import com.selection.SelectionOne;
import com.selection.SelectionTwo;

// TODO: Auto-generated Javadoc
/**
 * A factory for creating Operation objects depending upon the strategy called
 * by the user.
 */
public class OperationFactory implements AbstractFactory {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.factories.AbstractFactory#selectionChoice(int,
	 * com.generation.PopulationGenerator, com.generation.FitnessOperations) returns
	 * the instance of rank selection or tournament selection based on the strategy
	 * as per user requirement
	 */
	public Selection getSelectionChoice(int selectionType, PopulationGenerator populationGenerator,
			FitnessOperations fitnessOperation) {
		if (selectionType == 1) {
			return new SelectionOne(populationGenerator, fitnessOperation);
		} else if (selectionType == 2) {
			return new SelectionTwo(populationGenerator, fitnessOperation);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.factories.AbstractFactory#corssoverChoice(int,
	 * com.generation.PopulationGenerator, com.generation.FitnessOperations) returns
	 * the instance of one point crossover or two point crossover based on the
	 * strategy as per user requirement
	 */
	public Crossover getCrossoverChoice(int crossOverType, PopulationGenerator populationGenerator,
			FitnessOperations fitnessOperation) {
		if (crossOverType == 1) {
			return new CrossoverOne(populationGenerator, fitnessOperation);
		} else if (crossOverType == 2) {
			return new CrossoverTwo(populationGenerator, fitnessOperation);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.factories.AbstractFactory#mutateChoice(int,
	 * com.generation.PopulationGenerator, com.generation.FitnessOperations) returns
	 * the instance of uniform mutation or flip mutation based on the strategy as
	 * per user requirement
	 */
	public Mutation getMutateChoice(int mutateType, PopulationGenerator populationGenerator,
			FitnessOperations fitnessOperation) {
		if (mutateType == 1) {
			return new MutationOne(populationGenerator, fitnessOperation);
		} else if (mutateType == 2) {
			return new MutationTwo(populationGenerator, fitnessOperation);
		}
		return null;
	}

}

