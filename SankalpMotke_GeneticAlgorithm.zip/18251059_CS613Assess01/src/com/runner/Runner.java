package com.runner;

import java.util.Scanner;

import com.factories.FactoryProducer;
import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;
import com.geneticalgorithm.GeneticAlgorithm;
import com.strategy.GaStrategy;
import com.strategy.Strategy;

// TODO: Auto-generated Javadoc
/**
 * The Class Runner.
 */
public class Runner {

	/**
	 * The gaStrategy is instance of GaStrategy used to call the strategy decided by
	 * the user at run time
	 */
	static GaStrategy gaStrategy;

	/**
	 * The main method. Which is responsible to interact with the user.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

		/**
		 * scanner is object of Scanner class. Which takes input from the user.
		 */
		Scanner scanner = new Scanner(System.in);
		System.out.println(
				"\nPress 1,2,3 or 4 to select choices:\n\n1. Strategy-1 (Rank Selection, One point crossover and uniform mutation)"
						+ "\n2. Strategy-2 (Tournament Selection, Two point crossover and flip mutation)\n"
						+ "3. Strategy-3 (Rank Selection, Two point crossover and uniform mutation)\n"
						+ "4. Exit\n\nEnter your choice!");
		int userInput = scanner.nextInt();

		PopulationGenerator populationGenerator = PopulationGenerator.getInstance();

		System.out.println("\n*** Generating Population ***\n");

		FitnessOperations fitnessOperation = FactoryProducer.getFitnessOperations();
		populationGenerator.createPopulation();

		switch (userInput) {

		case 1:
			populationGenerator.printChromosome();
			gaStrategy = Strategy.setGAStrategy(1);
			int[] strategyA = gaStrategy.runStrategy();
			GeneticAlgorithm operationFactory1 = FactoryProducer.geneticAlgorithm();
			operationFactory1.doProcess(strategyA[0], strategyA[1], strategyA[2], populationGenerator,
					fitnessOperation);
			break;

		case 2:
			populationGenerator.printChromosome();
			gaStrategy = Strategy.setGAStrategy(2);
			int[] strategyB = gaStrategy.runStrategy();
			GeneticAlgorithm operationFactory2 = FactoryProducer.geneticAlgorithm();
			operationFactory2.doProcess(strategyB[0], strategyB[1], strategyB[2], populationGenerator,
					fitnessOperation);
			break;

		case 3:
			populationGenerator.printChromosome();
			gaStrategy = Strategy.setGAStrategy(3);
			int[] strategyC = gaStrategy.runStrategy();
			GeneticAlgorithm operationFactory3 = FactoryProducer.geneticAlgorithm();
			operationFactory3.doProcess(strategyC[0], strategyC[1], strategyC[2], populationGenerator,
					fitnessOperation);
			break;

		case 4:
			System.out.println("You have successfully exited the program");
			System.exit(0);
			break;

		default:
			System.out.println("Please enter valid number. Rerun the program");
			break;
		}

		/**
		 * Below code shows the thread safe singleton concept. Uncomment the below code
		 * and run the program. Two threads are trying to create population class
		 * instance. But only for the first time the object is created and from second
		 * time all the threads have to use single instance of the class to perform any
		 * operation.
		 */

		/*
		 * Thread t1 =new Thread(new Runnable() { public void run() {
		 * PopulationGenerator pop2 =PopulationGenerator.getInstance();
		 * System.out.println("\nInstance : "+pop);
		 * 
		 * } });
		 * 
		 * Thread t2 =new Thread(new Runnable() { public void run() {
		 * PopulationGenerator pop2 =PopulationGenerator.getInstance();
		 * System.out.println("Instance : "+pop2);
		 * 
		 * } });
		 * 
		 * t1.start(); t2.start();
		 */

	}
}
