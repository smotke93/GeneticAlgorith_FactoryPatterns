package com.selection;

import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Interface Selection.
 */
public interface Selection {

	/**
	 * Selection.
	 *
	 * @param populationgenerator is the instance of PopulationGenerator
	 * @param fitnessOperation    is the instance of FitnessOperation
	 */
	public void selection(PopulationGenerator populationgenerator, FitnessOperations fitnessOperation);
}
