package com.selection;

import com.generation.FitnessOperations;
import com.generation.GeneGenerator;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class SelectionOne implements rank type of selection..
 */
public class SelectionOne implements Selection {

	/**
	 * Instantiates a new selection one.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperation    is the instance of FitnessOperation
	 */
	public SelectionOne(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {
		selection(populationGenerator, fitnessOperation);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.selection.Selection#selection(com.generation.PopulationGenerator,
	 * com.generation.FitnessOperations) it performs rank selection on the
	 * population
	 */
	public void selection(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {

		GeneGenerator fittestChromosome;

		GeneGenerator secondFittestChromosome;

		System.out.println("After Selection");
		fittestChromosome = fitnessOperation.getFittest(populationGenerator);

		System.out.println("Fittest chromosome:" + fittestChromosome);

		secondFittestChromosome = fitnessOperation.getSecondFittest(populationGenerator);
		System.out.println("Second Fittest chromosome:" + secondFittestChromosome);
	}

}
