package com.selection;

import java.util.Random;

import com.generation.FitnessOperations;
import com.generation.GeneGenerator;
import com.generation.PopulationGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class SelectionTwo implements tournament type of selection.
 */
public class SelectionTwo implements Selection {

	/**
	 * Instantiates a new selection two.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @param fitnessOperation    is the instance of FitnessOperation
	 */
	public SelectionTwo(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {
		selection(populationGenerator, fitnessOperation);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.selection.Selection#selection(com.generation.PopulationGenerator,
	 * com.generation.FitnessOperations) it performs tournament selection on the
	 * population
	 */
	public void selection(PopulationGenerator populationGenerator, FitnessOperations fitnessOperation) {

		GeneGenerator fittestChromosome;
		GeneGenerator secondFittestChromosome;

		Random randomNumber = new Random();

		GeneGenerator[] geneGeneratorArray = new GeneGenerator[5];

		for (int i = 0; i < 5; i++) {
			int num = randomNumber.nextInt(10);
			geneGeneratorArray[i] = populationGenerator.getchromosome()[num];
			geneGeneratorArray[i].calculateFitness();

		}
		fittestChromosome = fitnessOperation.getFittest(populationGenerator);
		System.out.println("Fittest chromosome:" + fittestChromosome);
		secondFittestChromosome = fitnessOperation.getSecondFittest(populationGenerator);
		System.out.println("Second Fittest chromosome:" + secondFittestChromosome);

	}

}
