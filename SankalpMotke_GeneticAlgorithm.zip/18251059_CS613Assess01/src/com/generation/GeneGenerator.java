package com.generation;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

import com.runner.*;

// TODO: Auto-generated Javadoc
/**
 * The Class GeneGenerator.
 *
 * @author sankalpmotke class GeneGenerator : generates gene
 */
public class GeneGenerator {

	/** The fitness. */
	public int fitness = 0;

	/** The genes. */
	public int[] genes = new int[5];

	/** The gene length. */
	public int geneLength = 5;

	/** The target chromosome to find. */
	static int[] targetChromosome = new int[5];

	/** The random. */
	Random random = new Random();

	/**
	 * Gets the target string.
	 *
	 * the target string to be compared with the output of genetic algorithm
	 */
	public static void getTargetString() {

		System.out.print("Enter 5 digits target string to be found\n (Ony 0 and 1 allowed)\n");
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < targetChromosome.length; i++) {

			targetChromosome[i] = scanner.nextInt();
		}
	}

	/**
	 * Instantiates a new GeneGenerator. To create a gene of length of 5 (here gene
	 * length is considered to be 5)
	 */
	public GeneGenerator() {

		for (int i = 0; i < genes.length; i++) {
			genes[i] = Math.abs(random.nextInt() % 2);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 * 
	 * @return each genes of chromosome
	 */
	public String toString() {

		return Arrays.toString(this.genes);
	}

	/**
	 * Gets the genes.
	 *
	 * @return the genes
	 */
	public int[] getGenes() {
		return genes;
	}

	/**
	 * Calculate fitness.
	 *
	 * @return the fitness of each chromosome passed (e.g chromosome - 10101 has
	 *         fitness = 3)
	 */
	//[1]
	public int calculateFitness() {

		fitness = 0;
		for (int i = 0; i < 5; i++) {

			if (genes[i] == targetChromosome[i]) {
				++fitness;
			}

		}

		return fitness;

	}

}
/**
 * References
 * [1] https://towardsdatascience.com/introduction-to-genetic-algorithms-including-example-code-e396e98d8bf3
 */