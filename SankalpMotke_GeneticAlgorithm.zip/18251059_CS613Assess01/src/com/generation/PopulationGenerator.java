package com.generation;

import java.util.Arrays;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class PopulationGenerator.
 */
public class PopulationGenerator {

	/** The population size. */
	int populationSize = 10;

	/** The chromosome set contains all the chromosomes and forms a population. */
	public GeneGenerator[] chromosomeSet = new GeneGenerator[populationSize];

	/** The geneGenertor instance of GeneGenerator. */
	GeneGenerator geneGenertor = new GeneGenerator();

	/** The random. */
	Random random = new Random();

	/** The instance of PopulationGenerator made private and static. */
	private static PopulationGenerator instance;

	/**
	 * Instantiates a new population generator. Taken private to show the concept of
	 * singleton
	 */
	private PopulationGenerator() {

		geneGenertor.getTargetString();
	}

	/**
	 * Gets the single instance of PopulationGenerator.
	 *
	 * @return a single instance of PopulationGenerator each time when called. Due
	 *         to singleton concept used here.
	 */
	public static PopulationGenerator getInstance() // double checked locking
	{
		if (instance == null) {
			synchronized (PopulationGenerator.class) {
				if (instance == null) {
					instance = new PopulationGenerator();
				}
			}

		}

		return instance;

	}

	/**
	 * Creates the population.
	 */
	public void createPopulation() {
		for (int i = 0; i < chromosomeSet.length; i++) {
			chromosomeSet[i] = new GeneGenerator();
		}

	}

	/**
	 * Prints the chromosome.
	 */
	public void printChromosome() {
		for (int x = 0; x < getchromosome().length; x++) {
			System.out.println("Chromosome " + x + " " + Arrays.toString(getchromosome()[x].getGenes())
					+ " with Fitness = " + getchromosome()[x].calculateFitness());
		}
		System.out.println("\n");
	}

	/**
	 * Gets the chromosome.
	 *
	 * @return the chromosome set (i.e all population)
	 */
	public GeneGenerator[] getchromosome() {
		return chromosomeSet;

	}

}
