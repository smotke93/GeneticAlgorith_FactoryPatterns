package com.generation;

import java.util.Arrays;

// TODO: Auto-generated Javadoc
/**
 * The Class FitnessOperations.
 *
 * @author sankalpmotke
 * 
 *         class FitnessOPerations : has various methods such as getFittest,
 *         getSecondFittest and getLeastFittestIndex which are used to perform
 *         fitness operations on chromosome as per requirements (code
 *         re-usability)
 */
public class FitnessOperations {

	/** The fittest. */
	public int fittestChromosome = 0;

	/** The chromosome value. */
	protected String chromosomeValue;

	/** The second fittest chromosome. */
	protected String secondFittestChromosome;

	/**
	 * Gets the fittest chromosome.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @return the fittest chromosome
	 */
	
	//[1]
	public GeneGenerator getFittest(PopulationGenerator populationGenerator) {
		int maxFit = Integer.MIN_VALUE;
		int maxFitIndex = 0;
		for (int i = 0; i < populationGenerator.chromosomeSet.length; i++) {

			if (maxFit <= populationGenerator.chromosomeSet[i].fitness) {
				maxFit = populationGenerator.chromosomeSet[i].fitness;
				maxFitIndex = i;
			}
		}

		fittestChromosome = populationGenerator.chromosomeSet[maxFitIndex].fitness;
		chromosomeValue = Arrays.toString(populationGenerator.getchromosome()[maxFitIndex].getGenes());
		return populationGenerator.chromosomeSet[maxFitIndex];
	}

	/**
	 * Gets the second fittest chromosome.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @return the second fittest chromosome
	 */
	//[1]
	public GeneGenerator getSecondFittest(PopulationGenerator populationGenerator) {
		int maxFit1 = 0;
		int maxFit2 = 0;
		for (int i = 0; i < populationGenerator.chromosomeSet.length; i++) {
			if (populationGenerator.chromosomeSet[i].fitness > populationGenerator.chromosomeSet[maxFit1].fitness) {
				maxFit2 = maxFit1;
				maxFit1 = i;
			} else if (populationGenerator.chromosomeSet[i].fitness > populationGenerator.chromosomeSet[maxFit2].fitness) {
				maxFit2 = i;
			}
		}

		secondFittestChromosome = Arrays.toString(populationGenerator.getchromosome()[maxFit2].getGenes());
		return populationGenerator.chromosomeSet[maxFit2];
	}

	/**
	 * Gets the least fittest index of chromosome.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 * @return the least fittest index of chromosome
	 */
	//[1]
	public int getLeastFittestIndex(PopulationGenerator populationGenerator) {
		int minFitVal = Integer.MAX_VALUE;
		int minFitIndex = 0;
		for (int i = 0; i < populationGenerator.chromosomeSet.length; i++) {
			if (minFitVal >= populationGenerator.chromosomeSet[i].fitness) {
				minFitVal = populationGenerator.chromosomeSet[i].fitness;
				minFitIndex = i;
			}
		}
		return minFitIndex;
	}

	/**
	 * Calculate fitness of a chromosome.
	 *
	 * @param populationGenerator is the instance of PopulationGenerator
	 */
	//[1]
	public void calculateFitness(PopulationGenerator populationGenerator) {

		for (int i = 0; i < populationGenerator.chromosomeSet.length; i++) {

			populationGenerator.chromosomeSet[i].calculateFitness();

		}
		getFittest(populationGenerator);
	}

}

/**
 * References
 * [1] https://towardsdatascience.com/introduction-to-genetic-algorithms-including-example-code-e396e98d8bf3
 */
