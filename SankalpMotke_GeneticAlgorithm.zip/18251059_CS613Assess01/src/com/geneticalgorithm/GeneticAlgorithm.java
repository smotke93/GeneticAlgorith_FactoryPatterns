package com.geneticalgorithm;

import java.util.Random;

import com.crossover.Crossover;
import com.factories.OperationFactory;
import com.generation.FitnessOperations;
import com.generation.PopulationGenerator;
import com.mutation.Mutation;
import com.selection.Selection;

// TODO: Auto-generated Javadoc
/**
 * The Class GeneticAlgorithm.
 */
public class GeneticAlgorithm extends OperationFactory {

	/** The generation count before evolving population. */
	int generationCount = 0;

	/**
	 * The random number used for controlling the mutation rate. Which is very
	 * important factor in genetic algorithm
	 */
	Random random = new Random();

	/** The select is reference of type Selection. */
	Selection select;

	/** The cross is reference of type Crossover. */
	Crossover cross;

	/** The mutate is reference of type Mutation. */
	Mutation mutate;

	/**
	 * Gets the selection.
	 *
	 * @return the selection
	 */
	public Selection getSelection() {
		return select;
	}

	/**
	 * Gets the crossover.
	 *
	 * @return the crossover
	 */
	public Crossover getCrossover() {
		return cross;
	}

	/**
	 * Gets the mutation.
	 *
	 * @return the mutation
	 */
	public Mutation getMutation() {
		return mutate;
	}

	/**
	 * Do process.
	 *
	 * @param selectionType       : the selection type of (rank selection or
	 *                            tournament selection)
	 * @param crossOverType       : the cross over type of (one point crossover or
	 *                            two point crossover)
	 * @param mutateType          : the mutate type of (uniform mutation or flip
	 *                            mutation)
	 * @param populationGenerator : is the instance of population generator
	 * @param fitnessOperations   : is the instance of fitness operations
	 * @return the object
	 */
	public Object doProcess(int selectionType, int crossOverType, int mutateType,
			PopulationGenerator populationGenerator, FitnessOperations fitnessOperations) {

		System.out.println("In Generation : " + generationCount + " Fittest found : "
				+ fitnessOperations.getFittest(populationGenerator).fitness);

		//[1]
		while (fitnessOperations.getFittest(populationGenerator).fitness < 5) {

			++generationCount;

			select = getSelectionChoice(selectionType, populationGenerator, fitnessOperations);

			cross = getCrossoverChoice(crossOverType, populationGenerator, fitnessOperations);

			if (random.nextInt() < 0.25) {
				mutate = getMutateChoice(mutateType, populationGenerator, fitnessOperations);
			}

			fitnessOperations.calculateFitness(populationGenerator);

			System.out.println(
					"In Generation : " + generationCount + " Fittest found : " + fitnessOperations.fittestChromosome);
		}

		return null;
	}
}
/**
 * References
 * [1] https://towardsdatascience.com/introduction-to-genetic-algorithms-including-example-code-e396e98d8bf3
 */