package com.strategy;

// TODO: Auto-generated Javadoc
/**
 * The Class GaStrategyB.
 */
public class GaStrategyB extends GaStrategy {
	
	/* (non-Javadoc)
	 * 
	 * @see com.strategy.GaStrategy#runStrategy()
	 * GaStrategyA has Tournament Selection, Two point crossover and flip mutation
	 */
	@Override
	public int[] runStrategy()
	
	{	
		/**
		 *  setStrategy[0] = 2 has Tournament selection
		 *  setStrategy[1] = 2 has Two point crossover
		 *  setStrategy[2] = 2 has Flip mutation
		 */
	    int[] setStrategy = new int[3];
        setStrategy[0] = 2;
        setStrategy[1] = 2;
        setStrategy[2] = 2;
        return setStrategy;
	}

}
