package com.strategy;

// TODO: Auto-generated Javadoc
/**
 * The Class GaStrategy.
 */
public class GaStrategy {

	/**
	 * Run strategy.
	 *
	 * @return the int[]
	 */
	public int[] runStrategy() {
		return new int[0];
	}
}
