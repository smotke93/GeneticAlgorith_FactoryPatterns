package com.strategy;

// TODO: Auto-generated Javadoc
/**
 * The Class Strategy.
 */
public class Strategy {

	/**
	 * Instantiates a new strategy. Private constructor is created to hide the
	 * implicit public one
	 */
	private Strategy() {
	}

	/**
	 * Sets the GA strategy.
	 *
	 * @param userInput is taken from user to select strategy
	 * @return the instance of the strategy user wants to run at runtime
	 */
	public static GaStrategy setGAStrategy(int userInput) {

		if (userInput == 1) {
			return new GaStrategyA();
		} else if (userInput == 2) {
			return new GaStrategyB();
		} else if (userInput == 3) {
			return new GaStrategyC();
		}
		return null;

	}
}
