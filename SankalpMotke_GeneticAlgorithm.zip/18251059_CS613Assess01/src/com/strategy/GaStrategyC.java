package com.strategy;

//TODO: Auto-generated Javadoc
/**
 * The Class GaStrategyB.
 */
public class GaStrategyC extends GaStrategy {
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.strategy.GaStrategy#runStrategy() GaStrategyA has Rank Selection,
	 * Two point crossover and uniform mutation
	 */
	@Override
	public int[] runStrategy()

	{
		/**
		 * setStrategy[0] = 1 has Rank selection 
		 * setStrategy[1] = 2 has Two point crossover
		 * selection setStrategy[2] = 1 has Uniform mutation
		 */
		int[] setStrategy = new int[3];
		setStrategy[0] = 1;
		setStrategy[1] = 2;
		setStrategy[2] = 1;
		return setStrategy;

	}

}
